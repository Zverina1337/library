sum = 0

while True:
    num = int(input())
    if num == 0:
        break
    else:
        sum += num
    
print(sum)