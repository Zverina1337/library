n = input()
m = n
answer = 0
if(m % 2 != 0):
    answer = m + "���"

print(answer)