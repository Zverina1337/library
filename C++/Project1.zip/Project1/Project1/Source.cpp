#include <iostream>
using namespace std;
int const str = 4;
int const �olumn = 5;
int const* iStr = &str;
int const* iColumn = &�olumn;

int **sortArray(int array[str][�olumn]) {
	// i = ������
	// j = �������

	// ����� �������� "��"
	int iValue = 0;

	for (int *i = &iValue; *i < *iStr; (*(i))++)
	{	
		int jValue = 0;
		for (int *j = &jValue; *j < *iColumn; (*(j))++)
		{
			cout << array[*i][*j] << " ";
		}
		cout << endl;
		
	}
	iValue = 0;

	// ����������
	int type = 0;
	for (int* i = &iValue; *i < *iStr; (*(i))++)
	{
		int kValue = 1;
		for (int *k = &kValue; *k < *iColumn; (*(k))++)
		{
			int jValue = 0;
			for (int* j = &jValue; *j < *iColumn; (*(j))++)
			{
				if (array[0][*j] > array[0][*k])
				{
					int nValue = 0;
					for (int *n = &nValue; *n < *iStr; (*(n))++)
					{
						type = array[*n][*j];
						array[*n][*j] = array[*n][*k];
						array[*n][*k] = type;
					}				
				}
			}
		}
		cout << endl;
	}
	iValue = 0;

	// ����� �������� "�����"
	for (int* i = &iValue; *i < *iStr; (*(i))++)
	{
		int jValue = 0;
		for (int* j = &jValue; *j < *iColumn; (*(j))++)
		{
			cout << array[*i][*j] << " ";
		}
		cout << endl;

	}
	iValue = 0;

	return 0;
}

int main() {
	int array[str][�olumn] = {
		{2,1,3,7,6},
		{6,5,4,42,5},
		{7,9,8,3,6},
		{7,9,8,3,6},
	};
	int value = 0;
	sortArray(array);
}